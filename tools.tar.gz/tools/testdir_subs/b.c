/*
 * Tsinghua 
 * Project: Linux Tools
 * Author: liming
 */


int main(void)
{
}

/*
 * This is a test2 
 * func :  strcpy
 * @src:  source string
 * @dst:  destination string
 */
