// 001.cmt

int main(void)
{
}

// 002.cmt
